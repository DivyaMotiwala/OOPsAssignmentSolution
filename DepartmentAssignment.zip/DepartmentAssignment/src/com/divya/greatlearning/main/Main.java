package com.divya.greatlearning.main;

import com.divya.greatlearning.model.AdminDepartment;
import com.divya.greatlearning.model.HRDepartment;
import com.divya.greatlearning.model.TechDepartment;

public class Main {

	public static void main(String[] args) {
		
		//Create Admin Object and display functionalities
		AdminDepartment adminObject = new AdminDepartment();
		System.out.println(adminObject.getWelcomeMessage());
		System.out.println(adminObject.getTodaysWork());
		System.out.println(adminObject.getWorkDeadline());
		System.out.println(adminObject.isTodayAHoliday());
		
		//Formatting
		System.out.printf("\n\n\n");
		
		//Create HR Object and display functionalities
		HRDepartment hrObject = new HRDepartment();
		System.out.println(hrObject.getWelcomeMessage());
		System.out.println(hrObject.doActivity());
		System.out.println(hrObject.getTodaysWork());
		System.out.println(hrObject.getWorkDeadline());
		System.out.println(hrObject.isTodayAHoliday());
		
		//Formatting
		System.out.printf("\n\n\n");
		
		//Create Tech Object and display functionalities
		TechDepartment techObject = new TechDepartment();
		System.out.println(techObject.getWelcomeMessage());
		System.out.println(techObject.getTodaysWork());
		System.out.println(techObject.getWorkDeadline());
		System.out.println(techObject.getTechStackInformation());
		System.out.println(techObject.isTodayAHoliday());
		

	}

}
