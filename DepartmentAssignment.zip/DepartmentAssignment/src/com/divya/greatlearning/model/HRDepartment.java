package com.divya.greatlearning.model;

public class HRDepartment extends SuperDepartment {
	/*
	 * Overridden method to retrieve department name
	 */
	@Override
	public String departmentName() {
		
		return "Hr Department";
	}
	
	/*
	 * Overridden method to retrieve deadline
	 */
	@Override
	public String getWorkDeadline() {
		
		return "Complete by EOD ";
	}
	
	/*
	 * Overridden method to retrieve todays work
	 */
	@Override
	public String getTodaysWork() {
		
		return "Fill today�s timesheet and mark your attendance";
	}
	
	/*
	 * Method to do activity
	 */
	public String doActivity()
	{
		return "team Lunch";
	}
	
	/*
	 * Overridden method to retrieve welcome message
	 */
	@Override
	public String getWelcomeMessage() {
		
		return "Welcome to HR Department";
	}
}
