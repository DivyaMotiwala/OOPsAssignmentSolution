package com.divya.greatlearning.model;

public class AdminDepartment extends SuperDepartment {

	/*
	 * Overridden method to retrieve department name
	 */
	@Override
	public String departmentName() {
		
		return "Admin Department";
	}
	
	/*
	 * Overridden method to retrieve deadline
	 */
	@Override
	public String getWorkDeadline() {
		
		return "Complete by EOD ";
	}
	
	/*
	 * Overridden method to retrieve todays work
	 */
	@Override
	public String getTodaysWork() {
		
		return "Complete your documents Submission";
	}
	
	/*
	 * Overridden method to retrieve welcome message
	 */
	@Override
	public String getWelcomeMessage() {
		
		return "Welcome to Admin Department";
	}
}
