package com.divya.greatlearning.model;

/*
 * Parent Class for various Departments
 */
public class SuperDepartment {

	/*
	 * Get the name of department
	 * Input - None
	 * Output - String : Name of department
	 */
	public String departmentName()
	{
    	return "Super Department";
	}
    
	/*
	 * Get todays work
	 * Input - None
	 * Output - String : Todays Work
	 */
    public String getTodaysWork()
    {
    	return "No work as of now";
    }
    
    /*
	 * Get deadline of work
	 * Input - None
	 * Output - String : Deadline of work
	 */
    public String getWorkDeadline()
    {
    	return "Nil";
    }
    
    /*
	 * Check if today is a holiday
	 * Input - None
	 * Output - String : Holiday (True or False)
	 */
    public String isTodayAHoliday()
    {
    	return "Today is not a holiday";
    }
    
    /*
	 * Get Welcome message
	 * Input - None
	 * Output - String
	 */
    public String getWelcomeMessage()
    {
    	return "Welcome";
    }
    
}
